# HermesProxy\World\Client\PacketHandlers\GuildHandler.cs

## Part 1/4

None found.


## Part 2/4

None found.


## Part 3/4

None found.


## Part 4/4

None found.

